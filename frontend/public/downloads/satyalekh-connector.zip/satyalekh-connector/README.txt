Satyalekh connector — VF-7 website retrieval

Python 3.10+ required. Extract this folder, open a terminal here, then:

macOS / Linux:
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python anyror_worker.py

Windows PowerShell:
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe anyror_worker.py

Open https://satyalekh.vercel.app/retrieve and sign in. Enter the displayed
short-lived pairing code. Keep the code private. The connected account can
request public VF-7 parcels. Select the exact parcel and answer its official
CAPTCHA on the website. The original source and preliminary draft appear there.

Keep this computer awake and the connector running. Access expires after eight
hours. To stop it, press Ctrl+C; disconnect from the website to revoke access.
No inbound port, browser cookies, private files, remote commands, Gemini key or
Supabase key are needed. This connector only supports VF-7. Portal downtime,
CAPTCHA rejection and network failures can stop retrieval. Never treat a
preliminary revenue-record draft as a complete title clearance.
